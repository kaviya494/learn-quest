/**
 * AI Peer Teaching Kit - Client Environment Configuration
 * 
 * Since this application runs 100% client-side (directly via file:/// or static web server),
 * standard .env files cannot be read without a Node server.
 * 
 * You can also change this key at any time by clicking the "🔑 API Key"
 * button in the website's top navigation bar!
 */
window.ENV = {
  GEMINI_API_KEY: "AQ.Ab8RN6LYXk_FuOgX72O_xpSMUZsdEKzCChZt0WNXN5vCy4aeKA"
};
